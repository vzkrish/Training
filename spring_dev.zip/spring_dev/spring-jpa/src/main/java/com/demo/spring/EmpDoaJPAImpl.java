package com.demo.spring;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
@Transactional
public class EmpDoaJPAImpl implements EmpDao{

	@PersistenceContext
	EntityManager em;
	@Override
	public String SaveMe(Emp e) {
		// TODO Auto-generated method stub
		em.persist(e);
		return "Data Saved";
	}

	@Override
	public Emp Find(int EmpID) {
		// TODO Auto-generated method stub
		Emp emp = em.find(Emp.class, EmpID);
		return emp;
	}

	@Override
	public List<Emp> getEmpList() {
		Query qry = em.createQuery("select e from Emp e");
		return qry.getResultList();
	}

	@Override
	public String delete(int EmpID) {
		// TODO Auto-generated method stub
		Emp emp = Find(EmpID);
		em.remove(emp);
		return null;
	}

	@Override
	public String update(Emp e) {
		// TODO Auto-generated method stub
		Emp e1 = em.merge(e);
		return null;
	}

}
