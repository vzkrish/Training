package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;

public class MainDoa {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);

		EmpService service = (EmpService)ctx.getBean("empService");
		String mes = service.regsiterEmp(2101, "Krishnam Raju21", "Channai11", 30000);
		
		System.out.println("Message Saved" +mes);
		/*Emp emp = service.searchEmp(1000);
		
		if(emp.getEmpId() == 0)
		{
			System.out.println("No Emp Info with " +1000);
		}
		else
		{
		System.out.println(emp.getEmpId() + " " + emp.getEmpName() + " " + emp.getEmpCity() + " " + emp.getSalary());
		}
		
		List<Emp> empList = service.getAllEmp();
		
		for(Emp e:empList)
		{
			System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getEmpCity() + " " + e.getSalary());
		}*/
		
		
	}

}
