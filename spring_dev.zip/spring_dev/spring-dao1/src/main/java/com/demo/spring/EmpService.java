package com.demo.spring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class EmpService {
	
	@Autowired
	EmpDao dao; 
	
	/*public void setEmpDao(EmpDao dao)
	{
	   this.dao=dao;	
	}*/
	
	public String regsiterEmp(int EmpID, String EmpName, String EmpCity, double salary)
	{
		String resp = dao.SaveMe(new Emp(EmpID, EmpName, EmpCity, salary));
		return resp;
	}
	
	public Emp searchEmp(int EmpID)
	{
		return dao.Find(EmpID);
	}
	
	public List<Emp> getAllEmp()
	{
		return dao.getEmpList();
	}
	

}
