package com.demo.spring;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowCallbackHandler;
import org.springframework.jdbc.core.RowMapper;



public class selectMain {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
		JdbcTemplate jt = (JdbcTemplate)ctx.getBean("jdbcTemplate");
				
			List<Emp> empList = jt.query("select * from EMP", new RowMapper<Emp>()
				{

					@Override
					public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
						// TODO Auto-generated method stub
						return new Emp(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
					}
			
				}
				);
		for(Emp e:empList)
		{
			System.out.println(e.getEmpId() + " " + e.getEmpName() + " " + e.getEmpCity() + " " + e.getSalary());
		}
		
		System.out.println("With No for loop result:");
//		System.out.println("Rows Inserted " + count);
		
		jt.query("select * from EMP",new RowCallbackHandler()
				{
					@Override
					public void processRow(ResultSet rs) throws SQLException {
						System.out.println(rs.getInt("EMPNO") + " " + rs.getString("NAME") + " " + rs.getString("ADDRESS") + " " + rs.getDouble("SALARY"));
						
					}});

		Emp emp = jt.queryForObject("select * from EMP where EMPNO=21", new RowMapper<Emp>()
		{

			@Override
			public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
				// TODO Auto-generated method stub
				return new Emp(rs.getInt("EMPNO"),rs.getString("NAME"),rs.getString("ADDRESS"),rs.getDouble("SALARY"));
			}
			
		}
		);
		
			System.out.println(emp.getEmpId() + " " + emp.getEmpName() + " " + emp.getEmpCity() + " " + emp.getSalary());
				
		
		
	}

}


