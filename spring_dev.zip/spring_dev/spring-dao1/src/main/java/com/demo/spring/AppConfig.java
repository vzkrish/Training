package com.demo.spring;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ComponentScan(basePackages={"com.demo.spring"})
@EnableTransactionManagement
public class AppConfig {

	@Bean
	public DriverManagerDataSource dataSource()
	{
		DriverManagerDataSource Dds = new DriverManagerDataSource(); 
		Dds.setDriverClassName("com.mysql.jdbc.Driver");
		Dds.setUrl("jdbc:mysql://localhost:3306/springdb");
		Dds.setUsername("root");
		Dds.setPassword("root");
		return Dds;
	}
	
	@Bean	
	public JdbcTemplate jdbcTemplate()
	{
		JdbcTemplate jt = new JdbcTemplate();
		jt.setDataSource(dataSource());
		return jt;
		
	}
	
	@Bean
	public DataSourceTransactionManager transactionManager()
	{
		DataSourceTransactionManager tx = new DataSourceTransactionManager();
		tx.setDataSource(dataSource());
		return tx;
	}
}

